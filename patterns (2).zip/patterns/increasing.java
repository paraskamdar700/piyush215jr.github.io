public class increasing {
    
}
